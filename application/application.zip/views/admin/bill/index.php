<?php
if ($this->session->flashdata('sukses')) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
    echo $this->session->flashdata('sukses');
    echo ' <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
    </button>', '</div>';
}
?>

<div class="card elevation-5">
    <div class="card-body">
        <!-- Tabel daftar order  -->
        <div class="table-responsive">
            <table id="example1" class="table table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>ID Order</th>
                        <th>ID Pelanggan</th>
                        <th>Nama</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 0;
                    foreach ($order as $data) { //$order di ambil dari controller Admin nama file order nama function index
                        if ($data['order_status'] == 9) {
                            $no++;
                    ?>
                            <tr>
                                <td><?= $no ?></td>
                                <td>PLGN-00<?= $data['pelanggan_id'] ?></td>
                                <td>ORDER-00<?= $data['order_id'] ?></td>
                                <td><?= $data['pelanggan_nama'] ?></td>
                                <td>
                                    <?php
                                    $idorder = $data['order_id'];
                                    $query = $this->db->query("SELECT * FROM bill WHERE bill_order_id = $idorder");
                                    $bill = $query->row_array();
                                    if ($bill['bill_status'] == 1) {
                                        echo "Belum Bayar";
                                    } else if ($bill['bill_status'] == 2) {
                                        echo "Terbayar";
                                    } else if ($bill['bill_status'] == 3) {
                                        echo "Sebagian Terbayar";
                                    }
                                    ?>
                                </td>
                                <td class="content-center">
                                    <a href="<?= base_url('Admin/Bill/pembayaran/') . $data['order_id'] ?>" class="btn btn-info btn-sm text-bold">
                                        <!-- <li class="fas fa fa-file-invoice-dollar"></li> -->PEMBAYARAN
                                    </a>
                                    <a href="<?= base_url('Admin/Bill/penagihan/') . $data['order_id'] ?>" class="btn btn-warning btn-sm text-bold">
                                        <!-- <li class="fas fa fa-money-bill-alt"></li> -->PENAGIHAN
                                    </a>
                                </td>
                            </tr>
                    <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <!-- Batas akhir tabel order  -->
    </div>
</div>

<!-- POPUP hapus data  -->
<?php
foreach ($order as $p) {
?>
    <form action="<?= base_url('admin/order/delete') ?>" method="POST">
        <div class="modal fade1 bs-example-modal-lg" id="hapus<?= $p['order_id'] ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-md modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myLargeModalLabel">Hapus order</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>
                    <div class="modal-body">
                        <input type="text" name="id" value="<?= $p['order_id'] ?>" hidden>
                        Anda yakin ingin menghapus data order <?= $p['pelanggan_nama'] ?>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">
                            HAPUS
                        </button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php
}
?>