<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Validasi extends CI_Controller{
    
    public function index()
    {
        $data = array(
            'title'                => 'Validasi',
            'configurasi'          => $this->Konfigurasi_Model->listing(),
        );
        $this->load->view('validasi', $data);
    }

    public function validasiSetuju()
    {
        
        $i = $this->input;
        $id = $i->get('token');
        
        $query = $this->db->query("SELECT * FROM repair_order WHERE order_id = $id");
        $hasil = $query->row_array();
        
        if($hasil['order_status'] == 5 or $hasil['order_status'] == 6){
            
            $data = array(
                    'title'                => 'Validasi',
                    'configurasi'          => $this->Konfigurasi_Model->listing(),
                    'isi'               => "Konfirmasi Gagal"
                    );
            $this->load->view('validasi', $data);
        } else {
            
            $order = array(
                'order_id'      => $i->get('token'),
                'order_status'  => 5
            );
            $this->Order_Model->edit($order);
            redirect(base_url('Validasi'));
        }
    }

    public function validasiCancel()
    {
        $i = $this->input;
        $id = $i->get('token');
        
        $query = $this->db->query("SELECT * FROM repair_order WHERE order_id = $id");
        $hasil = $query->row_array();
        
        if($hasil['order_status'] == 5 or $hasil['order_status'] == 6){
            
            $data = array(
                    'title'                => 'Validasi',
                    'configurasi'          => $this->Konfigurasi_Model->listing(),
                    'isi'               => "Konfirmasi Gagal"
                    );
        $this->load->view('validasi', $data);
        } else {
            
            $order = array(
                'order_id'      => $i->get('token'),
                'order_status'  => 6
            );
            $this->Order_Model->edit($order);
            redirect(base_url('Validasi'));
        }
    }
}
