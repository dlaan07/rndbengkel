<br><?php
defined('BASEPATH') or exit('No direct script access allowed');

class PartOrder extends CI_Controller
{
    // public function __construct() {
    //   parent::__construct();
    //   ob_start();
    //  }
    public function tambahPengecekan()
    {
        $valid = $this->form_validation;
        $valid->set_rules('cek', 'Keperluan Suku Cadang', 'required');
        $valid->set_rules('jasa', 'Estimasi Biaya Jasa', 'required');
        $valid->set_rules('waktu', 'Estimasi Waktu Pengerjaan', 'required');
        $order_id = $this->input->post('idorder');
        if ($valid->run() === FALSE) {
            $data = array(
                'title'         => 'Pengecekan',
                'link'          => 'Pengecekan',
                'configurasi'   => $this->Konfigurasi_Model->listing(),
                'order'         => $this->Order_Model->getbyId($order_id),
                'part'          => $this->PartMaster_Model->listing(),
                'partOrder'     => $this->Part_Model->getbyId($order_id),
                'isi'           => 'teknisi/pengecekan/index'
            );
            $this->session->set_flashdata('gagal', 'Data pengecekan gagal disimpan');
            $this->load->view('teknisi/layout/wrapper', $data);
        } else {
            $i = $this->input;
            if ($i->post('cek') == 1) {
                $perbaikan = array(
                    'order_id'                  => $order_id,
                    'order_estimasiJasaWaktu'   => $i->post('waktu'),
                    'order_estimasiJasaHarga'   => $i->post('jasa')
                );
            } else {
                $email = $i->post('emailpel');
                $perbaikan = array(
                    'order_id'                  => $order_id,
                    'order_estimasiJasaWaktu'   => $i->post('waktu'),
                    'order_estimasiJasaHarga'   => $i->post('jasa'),
                    'order_status'              => 2
                );

                // $data = array(
                //     'order'         => $this->Order_Model->getbyId($order_id),
                //     'part'          => $this->Part_Model->getbyId($order_id),
                //     'po'            => $this->PurchaseOrder_Model->listing(),
                // );
                $this->_sendMail($email, $order_id);
            }

            $this->Order_Model->edit($perbaikan);
            redirect(base_url('Teknisi/Order/'));
        }
    }

    public function _sendMail($email, $order_id)
    {
        // Konfigurasi email
        $config = [
            // 'mailtype'  => 'html',
            // 'set_mailtype' => 'html',
            'charset'      => 'utf-8',
            'protocol'  => 'smtp',
            'smtp_host' => 'mail.kampung14bjs.com',
            'smtp_user' => 'eko25@kampung14bjs.com',  // Email gmail
            'smtp_pass'   => 'EkoZawa666',  // Password gmail
            'smtp_crypto' => 'ssl',
            'smtp_port'   => 465,
            'crlf'    => "\r\n",
            // 'set_newline' => "\r\n"
            // 'newline' => "\r\n"
        ];

        // Load library email dan konfigurasinya
        $this->load->library('email', $config);

        $this->email->set_newline("\r\n");
        $this->email->set_mailtype("html");
        // Email dan nama pengirim
        $this->email->from('eko25@kampung14bjs.com', 'Eko Aprianto');

        // Email penerima
        $this->email->to($email); // Ganti dengan email tujuan

        // Lampiran email, isi dengan url/path file
        // $this->email->attach(base_url('assets/vendors/images/login-img.png'));
        
        // Subject email
        $this->email->subject("Konfirmasi Estimasi Perbaikan Sepeda");

        // Isi email
        $order = $this->Order_Model->getbyId($order_id);
        $part  = $this->Part_Model->getbyId($order_id);
        $idorder = $order['order_id'];
        $harga = "
        <h3>Sepeda anda telah selesai dalam proses pengecekan</h3>
        <div>Dengan estimasi harga perbaikan adalah Rp ". number_format($order['order_estimasiJasaHarga'], 0, '', '.') . "</div><br>
        <div>Dan estimasi perbaikan selesai adalah ". $order['order_estimasiJasaWaktu']."</div>
        
        Jika anda setuju silahkan klik 
        <a href='http://kampung14bjs.com/Validasi/validasiSetuju?token=".$idorder."'><button> SETUJU </button></a><br>
        
        Jika anda tidak setuju silahkan klik 
        <a href='http://kampung14bjs.com/Validasi/validasiCancel?token=".$idorder."'><button> Tidak SETUJU </button></a><br>
        ";
        
        // Jika anda setuju dengan harga tersebeut silahkan klik <a href='https://kampung14bjs.com/Admin/Validasi/validasiSetuju'>Setuju</a><br>
        // Jika anda tidak setuju dengan harga tersebut silahkan klik <a href='https://kampung14bjs.com/Validasi/validasiCancel'>Tidak Setuju</a>
       // $harga = "Jika anda setuju dengan harga tersebeut silahkan klik <a href='https://kampung14bjs.com/Admin/Validasi/validasiSetuju>Setuju</a>";
       // $harga = "Jika anda tidak setuju dengan harga tersebeut silahkan klik <a href='https://kampung14bjs.com/Admin/Validasi/validasiCancel>Tidak</a>";
        $this->email->message($harga);

        // Tampilkan pesan sukses atau error
        if ($this->email->send()) {
            
            // redirect(base_url('Teknisi/Order'));
            echo 'Sukses! email berhasil dikirim.';
        } else {
            
            // redirect(base_url('Teknisi/Dashboard'));
            // echo 'Error! email tidak dapat dikirim.';
        }
    }
    
    
    public function tambahPartOrder()
    {
        $valid = $this->form_validation;
        $valid->set_rules('part', 'Nama Part', 'required');
        $valid->set_rules('qty', 'Qty', 'required');
        $order_id = $this->input->post('id');
        if ($valid->run() === FALSE) {
            $data = array(
                'title'         => 'Daftar Order',
                'link'          => 'Order',
                'configurasi'   => $this->Konfigurasi_Model->listing(),
                'order'         => $this->Order_Model->getbyId($order_id),
                'part'          => $this->PartMaster_Model->listing(),
                'partOrder'     => $this->Part_Model->getbyId($order_id),
                'isi'           => 'teknisi/pengecekan/index'
            );
            // redirect(base_url('teknisi/order/pengecekan/') . $order_id);
            $this->session->set_flashdata('gagal', 'Kebutuhan part gagal disimpan');
            $this->load->view('teknisi/layout/wrapper', $data);
        } else {
            $i = $this->input;
            $partMaster = $i->post('part');
            $query = $this->db->query("SELECT * FROM partmaster WHERE partMaster_id = $partMaster");
            $data = $query->row_array();
            $harga = $data['partMaster_harga'];
            $partOrder = array(
                'part_qtyDibutuhkan'    => $i->post('qty'),
                'part_tgl'              => date('Y-m-d'),
                'part_order_id'         => $i->post('id'),
                'part_partMaster_id'    => $partMaster,
                'part_harga'            => $harga
            );
            $this->Part_Model->tambah($partOrder);
            redirect(base_url('Teknisi/Order/Pengecekan/') . $order_id);
        }
    }

    public function partBaru()
    {
        $data = array(
            'title'         => 'Daftar Part Master',
            'link'          => 'Part Master',
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'part'          => $this->PartMaster_Model->listing(),
            'order'         => $this->Order_Model->getbyId($this->input->post('idorder')),
            'isi'           => 'teknisi/part/index'
        );
        $this->load->view('teknisi/layout/wrapper', $data);
    }

    public function simpanPart()
    {
        $valid = $this->form_validation;
        $valid->set_rules('part', 'Nama Part', 'required');
        if ($valid->run() === FALSE) {
            redirect(base_url('Teknisi/PartOrder/PartBaru/'));
            $this->session->set_flashdata('gagal', 'Kebutuhan part gagal disimpan');
        } else {
            $i = $this->input;
            $partmaster = array(
                'partMaster_nama'    => $i->post('part'),
                'partMaster_harga'   => $i->post('harga'),
                'partMaster_stok'    => $i->post('stok'),
                'partMaster_tgl'     => date('Y-m-d')
            );
            $this->PartMaster_Model->tambah($partmaster);
            $this->session->set_flashdata('sukses', 'Part baru berhasil disimpan');
            redirect(base_url('teknisi/PartOrder/partBaru/'));
        }
    }

    public function hapus()
    {
        $i = $this->input;

        $part = array(
            'part_id'          => $i->post('idpart')
        );
        $this->Part_Model->delete($part);
        redirect(base_url('Teknisi/Order/Pengecekan/') . $i->post('idorder'));
    }
}
