<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Bill extends CI_Controller
{
    public function index()
    {
        $data = array(
            'title'         => 'Daftar Bill',
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'link'          => 'Validasi',
            'order'         => $this->Order_Model->listing(),
            'isi'           => 'admin/bill/index'
        );

        $this->load->view('admin/layout/wrapper', $data);
    }

    public function penagihan($order_id)
    {
        $data = array(
            'title'         => 'Form Penagihan',
            'link'          => 'Penaghian',
            'order'         => $this->Order_Model->getbyId($order_id),
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'part'          => $this->Part_Model->getbyId($order_id),
            // 'po'            => $this->PurchaseOrder_Model->listing(),
            'bill'          => $this->Bill_Model->getbyId($order_id),
            'isi'           => 'admin/bill/penagihan'
        );

        $this->load->view('admin/layout/wrapper', $data);
    }

    public function simpanPenagihan()
    {
        $i = $this->input;
        $bill = array(
            'bill_id'       => $i->post('idorder'),
            'bill_jasa'     => $i->post('jasa'),
            'bill_total'    => $i->post('total'),
            'bill_tgl'      => date('Y-m-d')
        );
        $this->Bill_Model->edit($bill);
        $this->session->set_flashdata('sukses', 'Penagihan berhasil dibuat');
        redirect('Admin/Bill');
    }


    public function pembayaran($order_id)
    {
        $data = array(
            'title'         => 'Form Penagihan',
            'link'          => 'Penaghian',
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'order'         => $this->Order_Model->getbyId($order_id),
            'part'          => $this->Part_Model->getbyId($order_id),
            // 'po'            => $this->PurchaseOrder_Model->listing(),
            'bill'          => $this->Bill_Model->getbyId($order_id),
            'isi'           => 'admin/bill/pembayaran'
        );

        $this->load->view('admin/layout/wrapper', $data);
    }


    public function simpanPembayaran()
    {
        $valid = $this->form_validation;
        $valid->set_rules('bayar', 'Jumlah yang Dibayarkan', 'required');
        $valid->set_rules('metode', 'Metode Pembayaran', 'required');
        $valid->set_rules('ket', 'Keterangan', 'required');

        if ($valid->run() === FALSE) {
            redirect(base_url('Admin/Pelanggan'));
        } else {
            $i = $this->input;
            $bill = array(
                'bill_id'               => $i->post('idorder'),
                'bill_tglPembayaran'    => $i->post('tgl'),
                'bill_jenisPembayaran'  => $i->post('metode'),
                'bill_yangDibayar'      => $i->post('bayar'),
                'bill_keterangan'       => $i->post('ket')
            );
            $this->Bill_Model->edit($bill);
            $this->session->set_flashdata('sukses', 'Penagihan pembayaran berhasil dilakukan');
            redirect('Admin/Bill');
        }
    }
}
