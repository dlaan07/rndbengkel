<?php
if ($this->session->flashdata('sukses')) {
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
    echo $this->session->flashdata('sukses');
    echo ' <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
    </button>', '</div>';
}
$id = $this->session->userdata('id');
$nama = $this->session->userdata('nama');
$email = $this->session->userdata('email');
$username = $this->session->userdata('username');
?>
<h1>Welcome <?= $nama ?></h1>
<h1>Ini halaman dashboard Admin yaaa !</h1>
<?php
$pelanggan = $this->db->query('select * from pelanggan');
$jumlah = $pelanggan->num_rows();
echo $jumlah;
?>