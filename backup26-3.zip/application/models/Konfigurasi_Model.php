<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Konfigurasi_Model extends CI_Model
{

    public function __construct()
    {
        $this->load->database();
    }

    //query untuk menampilkan daftar pelanggan
    public function listing()
    {
        $this->db->select('*');
        $this->db->from('konfigurasi');
        $query = $this->db->get();
        return $query->row_array();
    }

    //query untuk menyimpan data yang dirubah (edit)
    public function edit($konfigurasi)
    {
        $this->db->where('config_id', $konfigurasi['config_id']);
        $this->db->update('konfigurasi', $konfigurasi);
    }
}
