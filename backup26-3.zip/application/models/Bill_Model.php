<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Bill_Model extends CI_Model
{

    public function __construct()
    {
        $this->load->database();
    }

    //query untuk menampilkan daftar bill
    public function listing()
    {
        $this->db->select('*');
        $this->db->from('bill');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function getbyId($order_id)
    {
        $this->db->select('*');
        $this->db->from('bill');
        $this->db->where('bill_order_id', $order_id);
        $query = $this->db->get();
        return $query->row_array();
    }

    //query untuk menyimpan data baru
    public function tambah($bill)
    {
        $this->db->insert('bill', $bill);
    }

    //query untuk menyimpan data yang dirubah (edit)
    public function edit($bill)
    {
        $this->db->where('bill_id', $bill['bill_id']);
        $this->db->update('bill', $bill);
    }

    //query untuk menghapus data
    public function delete($bill)
    {
        $this->db->where('bill_id', $bill['bill_id']);
        $this->db->delete('bill', $bill);
    }
}
