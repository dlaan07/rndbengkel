<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dp extends CI_Controller
{
    public function index()
    {
        $data = array(
            'title'         => 'Daftar DP',
            'link'          => 'DP',
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'order'         => $this->Bill_Model->dp(),
            'isi'           => 'admin/dp/index'
        );

        $this->load->view('admin/layout/wrapper', $data);
    }

    public function tambah()
    {
        $data = array(
            'title'         => 'Tambah DP',
            'link'          => 'DP',
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'order'         => $this->Order_Model->listing(),
            'isi'           => 'admin/dp/tambah'
        );

        $this->load->view('admin/layout/wrapper', $data);
    }

    public function simpanTambah()
    {
        $valid = $this->form_validation;
        $valid->set_rules('pelanggan', 'Pelanggan', 'required');
        $valid->set_rules('dp', 'Nilai DP', 'required');

        if ($valid->run() === FALSE) {
            $this->session->set_flashdata('gagal', 'DP gagal disimpan');
            redirect(base_url('Admin/Dp'));
        } else {
            $i = $this->input;
            $bill = array(
                'bill_order_id'     => $i->post('pelanggan'),
                'bill_dp'           => $i->post('dp'),
                'bill_dpKet'        => $i->post('keterangan'),
                'bill_bengkel'      => $this->session->userdata('bengkel'),
            );
            $this->Bill_Model->tambah($bill);

            $this->session->set_flashdata('sukses', 'DP berhasil di simpan');
            redirect(base_url('Admin/Dp'));
        }
    }

    public function edit($order_id)
    {
        $data = array(
            'title'         => 'Daftar DP',
            'link'          => 'DP',
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'order'         => $this->Bill_Model->editDp($order_id),
            'isi'           => 'admin/dp/edit'
        );

        $this->load->view('admin/layout/wrapper', $data);
    }

    public function simpanEdit()
    {
        $valid = $this->form_validation;
        $valid->set_rules('dp', 'Nilai DP', 'required');

        if ($valid->run() === FALSE) {
            $this->session->set_flashdata('gagal', 'DP gagal disimpan');
            redirect(base_url('Admin/Dp'));
        } else {
            $i = $this->input;
            $bill = array(
                'bill_id'           => $i->post('idbill'),
                'bill_dp'           => $i->post('dp'),
                'bill_dpKet'        => $i->post('keterangan')
            );
            $this->Bill_Model->edit($bill);

            $this->session->set_flashdata('sukses', 'DP berhasil di simpan');
            redirect(base_url('Admin/Dp'));
        }
    }

    public function print($order_id)
    {
        $data = array(
            'title'         => 'Print DP',
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'order'         => $this->Order_Model->getbyId($order_id),
            'part'          => $this->Part_Model->getbyId($order_id),
            'bill'          => $this->Bill_Model->getbyId($order_id),
            'isi'           => 'admin/dp/print'
        );

        $this->load->view('admin/layout/wrapper', $data);
    }
}
