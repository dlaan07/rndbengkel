<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Validasi extends CI_Controller{
    
    public function index()
    {
        $data = array(
            'title'                => 'Validasi',
            'configurasi'          => $this->Konfigurasi_Model->listing(),
        );
        $this->load->view('validasi', $data);
    }
    
     public function detail()
    {
        $order_id = $this->input->get('token');

        $data = array(
            'title'         => 'Daftar Validasi',
            'link'          => 'Validasi',
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'order'         => $this->Order_Model->getbyId($order_id),
            'part'          => $this->Part_Model->getbyId($order_id),
            'po'            => $this->PurchaseOrder_Model->listing()
        );

        $this->load->view('validasiTemplate', $data);
    }
    
    public function validasiSetuju()
    {
        
        $i = $this->input;
        $id = $i->get('token');
        
        $query = $this->db->query("SELECT * FROM repair_order WHERE order_id = $id");
        $hasil = $query->row_array();
        
        if($hasil['order_status'] > 4){
            
            $data = array(
                    'title'                => 'Validasi',
                    'configurasi'          => $this->Konfigurasi_Model->listing(),
                    'isi'               => "Konfirmasi Gagal"
                    );
            $this->load->view('validasi', $data);
        } else {
            
            $order = array(
                'order_id'      => $i->get('token'),
                'order_status'  => 5
            );
            $this->Order_Model->edit($order);
            redirect(base_url('Validasi'));
        }
    }

    public function validasiCancel()
    {
        $i = $this->input;
        $id = $i->get('token');
        
        $query = $this->db->query("SELECT * FROM repair_order WHERE order_id = $id");
        $hasil = $query->row_array();
        
        if($hasil['order_status'] > 4){
            
            $data = array(
                    'title'                => 'Validasi',
                    'configurasi'          => $this->Konfigurasi_Model->listing(),
                    'isi'               => "Konfirmasi Gagal"
                    );
        $this->load->view('validasi', $data);
        } else {
            
            $order = array(
                'order_id'      => $i->get('token'),
                'order_status'  => 6
            );
            $this->Order_Model->edit($order);
            redirect(base_url('Validasi'));
        }
    }
}
