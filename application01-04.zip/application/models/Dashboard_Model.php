<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard_Model extends CI_Model
{

    public function __construct()
    {
        $this->load->database();
    }

    //query untuk menampilkan daftar pelanggan
    public function pelanggan()
    {
        $this->db->select('*');
        $this->db->from('pelanggan');
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function order()
    {
        // $this->db->select('*');
        // $this->db->from('repair_order');
        // $this->db->where('order_status', '<7');
        $query = $this->db->query("SELECT * FROM repair_order where order_status < 8");
        return $query->num_rows();
    }
    
    public function perbaikan()
    {
        // $this->db->select('*');
        // $this->db->from('repair_order');
        // $this->db->where('order_status', '>7');
        $query = $this->db->query("SELECT * FROM repair_order where order_status > 7");
        return $query->num_rows();
    }

    public function parts()
    {
        $this->db->select('*');
        $this->db->from('partmaster');
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function bill()
    {
        $query = $this->db->query("SELECT * from bill ");
        return $query->result_array();
    }
}
