<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Tracking extends CI_Controller
{
    public function index()
    {
        $data = array(
            'title'         => 'Dashboard',
            'link'          => 'Dashboard',
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'order'         => $this->PurchaseOrder_Model->listing(),
            'isi'           => 'gudang/tracking/index'
        );
        $this->load->view('gudang/layout/wrapper', $data);
    }

    public function detail($idorder)
    {
        $data = array(
            'title'         => 'Detail Part',
            'link'          => 'Detail Part',
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'partOrder'     => $this->PurchaseOrder_Model->getbyPO($idorder),
            'isi'           => 'gudang/tracking/detail'
        );
        $this->load->view('gudang/layout/wrapper', $data);
    }

    public function updateTracking()
    {
        $po_id = $this->input->post('idpo');
        $data = array(
            'title'         => 'Update Tracking',
            'link'          => 'Update Tracking',
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'part'          => $this->PurchaseOrder_Model->getbyId($po_id),
            'isi'           => 'gudang/tracking/update'
        );
        $this->load->view('gudang/layout/wrapper', $data);
    }

    public function simpan()
    {
        $i = $this->input;
        $po_id = $i->post('idorder');
        $purchaseorder = array(
            'po_id'                 => $i->post('idpo'),
            'po_tracking'           => $i->post('cek')
        );
        $this->PurchaseOrder_Model->edit($purchaseorder);
        redirect(base_url('Gudang/Tracking/Detail/') . $po_id);
    }
}
