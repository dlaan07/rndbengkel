<?php
if ($this->session->flashdata('sukses')) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
    echo $this->session->flashdata('sukses');
    echo ' <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
    </button>', '</div>';
}
?>

<div class="card elevation-5">
    <div class="card-body">
        <!-- Tabel daftar order  -->
        <div class="table-responsive">
            <table id="example1" class="table table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>ID Order</th>
                        <th>ID Pelanggan</th>
                        <th>Nama</th>
                        <th>Total Penagihan</th>
                        <th>Total Pembayaran</th>
                        <th>Status Pembayaran</th>
                        <th>Status Test Drive</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 0;
                    foreach ($order as $data) { //$order di ambil dari controller Admin nama file order nama function index
                    $idorder = $data['order_id'];
                    $query = $this->db->query("SELECT * FROM bill WHERE bill_order_id = $idorder");
                    $bill = $query->row_array();
                        if ($data['order_status'] == 9) {
                            $no++;
                    ?>
                            <tr>
                                <td><?= $no ?></td>
                                <td>PLGN-00<?= $data['pelanggan_id'] ?></td>
                                <td>ORDER-00<?= $data['order_id'] ?></td>
                                <td><?= $data['pelanggan_nama'] ?></td>
                                <td>Rp <?= number_format($bill['bill_total'], 0, "", ".")?></td>
                                <td>Rp <?= number_format($bill['bill_yangDibayar'], 0, "", ".")?></td>
                                <td>
                                    <?php
                                    if ($bill['bill_status'] == 1) {
                                        echo "<span class='badge badge-danger'>Belum Bayar</span>";
                                    } else if ($bill['bill_status'] == 2) {
                                        echo "<span class='badge badge-primary'>Lunas</span>";
                                        if ($bill['bill_yangDibayar'] > $bill['bill_total']) {
                                            $kembali = $bill['bill_yangDibayar'] - $bill['bill_total'];
                                            echo "<br><span class='badge badge-info'>Kembali Rp. ". number_format($kembali, 0, "", ".") ."</span>";
                                        }
                                    } else if ($bill['bill_status'] == 3) {
                                        echo "<span class='badge badge-warning'>Sebagian Terbayar</span><br>";
                                        $sisa = $bill['bill_total'] - $bill['bill_yangDibayar'];
                                        echo "<span class='badge badge-info'>Sisa Rp. ". number_format($sisa, 0, "", ".") ."</span>";
                                    }
                                    ?>
                                </td>
                                <td><?= $bill['bill_qc'] ?></td>
                                <td class="content-center">
                                    <a href="<?= base_url('Admin/Bill/penagihan/') . $data['order_id'] ?>" class="btn btn-warning btn-sm text-bold" <?php if ($bill['bill_total'] != "") {echo "hidden"; }?>>
                                        <!-- <li class="fas fa fa-money-bill-alt"></li> -->PENAGIHAN
                                    </a>
                                    <a href="<?= base_url('Admin/Bill/pembayaran/') . $data['order_id'] ?>" class="btn btn-info btn-sm text-bold" <?php if ($bill['bill_status'] == 2 ) {echo "hidden"; }?>>
                                        <!-- <li class="fas fa fa-file-invoice-dollar"></li> -->PEMBAYARAN
                                    </a>
                                    <a href="<?= base_url('Admin/Bill/qc/') . $data['order_id'] ?>" class="btn btn-warning btn-sm text-bold" <?php if ($bill['bill_tgl'] == "" or $bill['bill_order_id'] != $data['order_id']) {echo "hidden"; } ?>>
                                        <!-- <li class="fas fa fa-file-invoice-dollar"></li> -->TEST DRIVE
                                    </a>
                                </td>
                            </tr>
                    <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <!-- Batas akhir tabel order  -->
    </div>
</div>