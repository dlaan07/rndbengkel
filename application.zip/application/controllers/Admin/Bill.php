<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Bill extends CI_Controller
{
    public function index()
    {
        $data = array(
            'title'         => 'Daftar Bill',
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'link'          => 'Validasi',
            'order'         => $this->Order_Model->listing(),
            'isi'           => 'admin/bill/index'
        );

        $this->load->view('admin/layout/wrapper', $data);
    }

    public function penagihan($order_id)
    {
        $data = array(
            'title'         => 'Form Penagihan',
            'link'          => 'Penaghian',
            'order'         => $this->Order_Model->getbyId($order_id),
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'part'          => $this->Part_Model->getbyId($order_id),
            // 'po'            => $this->PurchaseOrder_Model->listing(),
            'bill'          => $this->Bill_Model->getbyId($order_id),
            'isi'           => 'admin/bill/penagihan'
        );

        $this->load->view('admin/layout/wrapper', $data);
    }

    public function simpanPenagihan()
    {
        $i = $this->input;
        $email = $i->post('email');
        $order_id = $i->post('order');
        $bill_id = $i->post('idorder');
        
        if(!empty($bill_id)){
        
            $bill = array(
                'bill_id'       => $bill_id,
                'bill_jasa'     => $i->post('jasa'),
                'bill_total'    => $i->post('total'),
                'bill_tgl'      => date('Y-m-d')
            );
            
            $this->Bill_Model->edit($bill);
            
            } else {
                 $bill = array(
                'bill_jasa'     => $i->post('jasa'),
                'bill_total'    => $i->post('total'),
                'bill_tgl'      => date('Y-m-d'),
                'bill_order_id' => $order_id,
            );
            
            $this->Bill_Model->tambah($bill);
        }
        // $this->session->set_flashdata('sukses', 'Penagihan berhasil dibuat');
        $this->_sendMail($email, $order_id);
        
    }


    public function pembayaran($order_id)
    {
        $data = array(
            'title'         => 'Form Penagihan',
            'link'          => 'Penaghian',
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'order'         => $this->Order_Model->getbyId($order_id),
            'part'          => $this->Part_Model->getbyId($order_id),
            // 'po'            => $this->PurchaseOrder_Model->listing(),
            'bill'          => $this->Bill_Model->getbyId($order_id),
            'isi'           => 'admin/bill/pembayaran'
        );

        $this->load->view('admin/layout/wrapper', $data);
    }


    public function simpanPembayaran()
    {
        $valid = $this->form_validation;
        $valid->set_rules('bayar', 'Jumlah yang Dibayarkan', 'required');
        $valid->set_rules('metode', 'Metode Pembayaran', 'required');
        // $valid->set_rules('ket', 'Keterangan', 'required');

        if ($valid->run() === FALSE) {
            redirect(base_url('Admin/Bill'));
        } else {
            
            $i = $this->input;
            $idbill = $i->post('idorder');
            $bayar = $this->db->query("SELECT * FROM bill where bill_id = $idbill");
            $total = $bayar->row_array();
            $sisa = $total['bill_total'] - $i->post('bayar');
            if ($sisa <= 0) {
                $status = 2;
            } else if ($sisa > 0) {
                $status = 3;
            }
            $bill = array(
                'bill_id'               => $idbill,
                'bill_tglPembayaran'    => $i->post('tgl'),
                'bill_jenisPembayaran'  => $i->post('metode'),
                'bill_yangDibayar'      => $i->post('bayar'),
                'bill_keterangan'       => $i->post('ket'),
                'bill_status'           => $status
            );
            $this->Bill_Model->edit($bill);
            $this->session->set_flashdata('sukses', 'Penagihan pembayaran berhasil dilakukan');
            redirect('Admin/Bill');
        }
    }
    
    
    public function _sendMail($email, $order_id)
    {
        // Konfigurasi email
        $config = [
            // 'mailtype'  => 'html',
            // 'set_mailtype' => 'html',
            'charset'      => 'utf-8',
            'protocol'  => 'smtp',
            'smtp_host' => 'bengkel.intala.com',
            'smtp_user' => 'info@bengkel.intala.com',  // Email gmail
            'smtp_pass'   => 'bengkel2021',  // Password gmail
            'smtp_crypto' => 'ssl',
            'smtp_port'   => 465,
            'crlf'    => "\r\n",
            // 'set_newline' => "\r\n"
            // 'newline' => "\r\n"
        ];

        // Load library email dan konfigurasinya
        $this->load->library('email', $config);

        $this->email->set_newline("\r\n");
        $this->email->set_mailtype("html");
        // Email dan nama pengirim
        $this->email->from('info@bengkel.intala.com', 'Bengkel Intala');

        // Email penerima
        $this->email->to($email); // Ganti dengan email tujuan

        // Lampiran email, isi dengan url/path file
        // $this->email->attach(base_url('assets/vendors/images/login-img.png'));

        // Subject email
        $this->email->subject("Informasi Pembayaran Perbaikan Sepeda");

        // Isi email
        $data = array(
            'order'         => $this->Order_Model->getbyId($order_id),
            'part'          => $this->Part_Model->getbyId($order_id),
            // 'po'            => $this->PurchaseOrder_Model->listing(),
            'bill'          => $this->Bill_Model->getbyId($order_id)
        );

        
        $harga = $this->load->view('penagihan', $data, TRUE);

        $this->email->message($harga);

        // Tampilkan pesan sukses atau error
        if ($this->email->send()) {

            redirect('Admin/Bill');
            // echo 'Sukses! email berhasil dikirim.';
        } else {

            redirect('Admin/Dashboard');
            // echo 'Error! email tidak dapat dikirim.';
        }
    }
    
    public function qc($order_id)
    {
        $data = array(
            'title'         => 'Form Perbaikan Ulang',
            'link'          => 'Perbaikan Ulang',
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'order'         => $this->Order_Model->getbyId($order_id),
            'part'          => $this->Part_Model->getbyId($order_id),
            'bill'          => $this->Bill_Model->getbyId($order_id),
            'isi'           => 'admin/bill/qc'
        );

        $this->load->view('admin/layout/wrapper', $data);
    }
    
     public function simpanQc()
    {
        $valid = $this->form_validation;
        $valid->set_rules('qc', 'Status Perbaikan Ulang', 'required');

        if ($valid->run() === FALSE) {
            redirect(base_url('Admin/Bill'));
        } else {
            
            $i = $this->input;
            $idbill = $i->post('idorder');
            $bill = array(
                'bill_id'           => $idbill,
                'bill_qc'           => $i->post('qc'),
                'bill_qcKet'        => $i->post('ket')
            );
            $this->Bill_Model->edit($bill);
            $this->session->set_flashdata('sukses', 'Perbaikan Ulang berhasil dilakukan');
            redirect('Admin/Bill');
        }
    }
}
