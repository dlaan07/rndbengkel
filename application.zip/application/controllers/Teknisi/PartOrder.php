<?php
defined('BASEPATH') or exit('No direct script access allowed');

class PartOrder extends CI_Controller
{
    // public function __construct() {
    //   parent::__construct();
    //   ob_start();
    //  }
    public function tambahPengecekan()
    {
        $valid = $this->form_validation;
        $valid->set_rules('cek', 'Keperluan Suku Cadang', 'required');
        $valid->set_rules('jasa', 'Estimasi Biaya Jasa', 'required');
        $valid->set_rules('waktu', 'Estimasi Waktu Pengerjaan', 'required');
        $order_id = $this->input->post('idorder');
        if ($valid->run() === FALSE) {
            $data = array(
                'title'         => 'Pengecekan',
                'link'          => 'Pengecekan',
                'configurasi'   => $this->Konfigurasi_Model->listing(),
                'order'         => $this->Order_Model->getbyId($order_id),
                'part'          => $this->PartMaster_Model->listing(),
                'partOrder'     => $this->Part_Model->getbyId($order_id),
                'isi'           => 'teknisi/pengecekan/index'
            );
            $this->session->set_flashdata('gagal', 'Data pengecekan gagal disimpan');
            $this->load->view('teknisi/layout/wrapper', $data);
        } else {
            $i = $this->input;
            $cek = $i->post('cek');
            if ( $cek == 1) {
                $perbaikan = array(
                    'order_id'                  => $order_id,
                    'order_estimasiJasaWaktu'   => $i->post('waktu'),
                    'order_estimasiJasaHarga'   => $i->post('jasa')
                );
                    
                $this->Order_Model->edit($perbaikan);
            } else {
                $email = $i->post('emailpel');
                $perbaikan = array(
                    'order_id'                  => $order_id,
                    'order_estimasiWaktu'       => $i->post('waktu'),
                    'order_estimasiJasaWaktu'   => $i->post('waktu'),
                    'order_estimasiJasaHarga'   => $i->post('jasa'),
                    'order_status'              => 2
                );
                
                $this->Order_Model->edit($perbaikan);
                $this->_sendMail($email, $order_id);
            }

            redirect(base_url('Teknisi/Order/'));
        }
    }

    public function _sendMail($email, $order_id)
    {
        // Konfigurasi email
        $config = [
            // 'mailtype'  => 'html',
            // 'set_mailtype' => 'html',
            'charset'      => 'utf-8',
            'protocol'  => 'smtp',
            'smtp_host' => 'bengkel.intala.com',
            'smtp_user' => 'info@bengkel.intala.com',  // Email gmail
            'smtp_pass'   => 'bengkel2021',  // Password gmail
            'smtp_crypto' => 'ssl',
            'smtp_port'   => 465,
            'crlf'    => "\r\n",
            // 'set_newline' => "\r\n"
            // 'newline' => "\r\n"
        ];

        // Load library email dan konfigurasinya
        $this->load->library('email', $config);

        $this->email->set_newline("\r\n");
        $this->email->set_mailtype("html");
        // Email dan nama pengirim
        $this->email->from('info@bengkel.intala.com', 'Bengkel Intala');

        // Email penerima
        $this->email->to($email); // Ganti dengan email tujuan

        // Lampiran email, isi dengan url/path file
        // $this->email->attach(base_url('assets/vendors/images/login-img.png'));

        // Subject email
        $this->email->subject("Konfirmasi Estimasi Perbaikan Sepeda");

        // Isi email
        $data = array(
            'title'         => 'Daftar Validasi',
            'link'          => 'Validasi',
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'order'         => $this->Order_Model->getbyId($order_id),
            'part'          => $this->Part_Model->getbyId($order_id),
            'po'            => $this->PurchaseOrder_Model->listing()
        );
        
        $harga = $this->load->view('konfirmasi', $data, TRUE);

        $this->email->message($harga);

        // Tampilkan pesan sukses atau error
        if ($this->email->send()) {

            // redirect(base_url('Teknisi/Order'));
            echo 'Sukses! email berhasil dikirim.';
        } else {

            // redirect(base_url('Teknisi/Dashboard'));
            // echo 'Error! email tidak dapat dikirim.';
        }
    }


    public function tambahPartOrder()
    {
        $valid = $this->form_validation;
        $valid->set_rules('part', 'Nama Part', 'required');
        $valid->set_rules('qty', 'Qty', 'required');
        $order_id = $this->input->post('id');
        if ($valid->run() === FALSE) {
            $data = array(
                'title'         => 'Daftar Order',
                'link'          => 'Order',
                'configurasi'   => $this->Konfigurasi_Model->listing(),
                'order'         => $this->Order_Model->getbyId($order_id),
                'part'          => $this->PartMaster_Model->listing(),
                'partOrder'     => $this->Part_Model->getbyId($order_id),
                'isi'           => 'teknisi/pengecekan/index'
            );
            // redirect(base_url('teknisi/order/pengecekan/') . $order_id);
            $this->session->set_flashdata('gagal', 'Kebutuhan part gagal disimpan');
            $this->load->view('teknisi/layout/wrapper', $data);
        } else {
            $i = $this->input;
            $partMaster = $i->post('part');
            $qty = $i->post('qty');
            $query = $this->db->query("SELECT * FROM partmaster WHERE partMaster_id = $partMaster");
            $data = $query->row_array();
            $harga = $data['partMaster_harga'];
            $partOrder = array(
                'part_qtyDibutuhkan'    => $qty,
                'part_tgl'              => date('Y-m-d'),
                'part_order_id'         => $i->post('id'),
                'part_partMaster_id'    => $partMaster,
                'part_harga'            => $harga
            );
            $this->Part_Model->tambah($partOrder);
            
            // $stok = $data['partMaster_stok'] - $data['partMaster_par'] - $qty; // -1 + 0 + 2 = 1
            
            // if ($data['partMaster_stok'] > 0) {
            //     if ($stok >= 0) {
            //         $hasil = $data['partMaster_stok'] - $qty; // 1 - 2 = -1
            //         $partmaster = array(
            //             'partMaster_id'      => $partMaster,
            //             'partMaster_stok'    => $hasil
            //         );
            //         $this->PartMaster_Model->edit($partmaster);
            //     } else {
            //         $hasil = $data['partMaster_stok'] - $qty; // 1 -
            //         $partmaster = array(
            //             'partMaster_id'      => $partMaster,
            //             'partMaster_stok'    => $hasil
            //         );
            //         $this->PartMaster_Model->edit($partmaster);
            //     }
                 
            // }
            
            redirect(base_url('Teknisi/Order/Pengecekan/') . $order_id);
        }
    }

    public function partBaru($order_id)
    {
        $data = array(
            'title'         => 'Daftar Part Master',
            'link'          => 'Part Master',
            'configurasi'   => $this->Konfigurasi_Model->listing(),
            'part'          => $this->PartMaster_Model->listing(),
            'order'         => $this->Order_Model->getbyId($order_id),
            'isi'           => 'teknisi/part/index'
        );
        $this->load->view('teknisi/layout/wrapper', $data);
    }

    public function simpanPart()
    {
        $valid = $this->form_validation;
        $valid->set_rules('part', 'Nama Part', 'required');
        
        
        $i = $this->input;
        $order_id = $i->post('idorder');
        if ($valid->run() === FALSE) {
            redirect(base_url('Teknisi/PartOrder/PartBaru/'));
            $this->session->set_flashdata('gagal', 'Kebutuhan part gagal disimpan');
        } else {
            $partmaster = array(
                'partMaster_nama'    => $i->post('part'),
                'partMaster_harga'   => $i->post('harga'),
                'partMaster_stok'    => $i->post('stok'),
                'partMaster_tgl'     => date('Y-m-d')
            );
            $this->PartMaster_Model->tambah($partmaster);
            $this->session->set_flashdata('sukses', 'Part baru berhasil disimpan');
            redirect(base_url('Teknisi/PartOrder/partBaru/') . $order_id);
        }
    }

    public function hapus()
    {
        $i = $this->input;
        
        // $partMaster = $i->post('part');
        // $qty = $i->post('qty');
        // $query = $this->db->query("SELECT * FROM partmaster WHERE partMaster_id = $partMaster");
        // $data = $query->row_array();
        
        // $a = $data['partMaster_stok'] + $qty;     // 8 + 2 = 10        // -1 + 2 = 1            // 0 + 7 = 7          // 1 + 7 = 8
        // $c = $a - $data['partMaster_par'] - $qty; // 10 - 2 - 2 = 6    // 2 - 0 - 2 = 0        // 7 - 2 - 7 = -2      // 8 - 2 - 7 = -1
        
        // $b = $data['partMaster_Stok'] + $data['partMaster_par'] + $qty; 
        
        $part = array(
            'part_id'          => $i->post('idpart')
        );
        
        // if ($data['partMaster_stok'] < 0){
        // $stok = $data['partMaster_stok'] + $qty;
        // $partmaster = array(
        //     'partMaster_id'      => $partMaster,
        //     'partMaster_stok'    => $stok
        // );
        // $this->PartMaster_Model->edit($partmaster);
        // }else{
        //     if ($c != $data['partMaster_stok']) {
        //         // echo "data tidak sama dg stok";
        //         // $hasil = $a - $data['partMaster_par'] - $qty;
        //         // if ($hasil >= 0){
        //             $stok = $data['partMaster_stok'] + $qty;
        //             $partmaster = array(
        //                 'partMaster_id'      => $partMaster,
        //                 'partMaster_stok'    => $stok
        //             );
        //             $this->PartMaster_Model->edit($partmaster);
        //         // }
        //     }
        // }
        
        $this->Part_Model->delete($part);
        redirect(base_url('Teknisi/Order/Pengecekan/') . $i->post('idorder'));
    }
}
